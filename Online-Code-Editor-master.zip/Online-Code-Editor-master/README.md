Install node modules for running this file
